/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Maison MP Motors - Desktop Title Bar & Session Header
 */

import React, { useState, useEffect } from 'react';
import {
  Wrench,
  WifiOff,
  UserCheck,
  Clock,
  Keyboard,
  ChevronDown,
  DollarSign,
  ShieldCheck,
  Building2,
  RefreshCw,
  Download,
  Crown,
  Database,
  Palette,
  Sun,
  Moon,
  LogOut,
} from 'lucide-react';
import { User, Role } from '../shared/types';
import { storage } from '../services/storage';
import { getUserLicenseStatus } from '../shared/permissions';
import { dbConfigService } from '../services/dbConfigService';

interface DesktopHeaderProps {
  currentUser: User;
  onUserChange: (user: User) => void;
  onOpenShortcuts: () => void;
  onOpenDbConfig?: () => void;
  onOpenThemeConfig?: () => void;
  onLogout?: () => void;
}

export const DesktopHeader: React.FC<DesktopHeaderProps> = ({
  currentUser,
  onUserChange,
  onOpenShortcuts,
  onOpenDbConfig,
  onOpenThemeConfig,
  onLogout,
}) => {
  const [params, setParams] = useState(storage.getParams());
  const [allUsers, setAllUsers] = useState<User[]>(storage.getUsers());
  const [dbConfig] = useState(() => dbConfigService.getConfig());
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [time, setTime] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTime(
        now.toLocaleTimeString('fr-FR', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleSwitchUser = (user: User) => {
    storage.setCurrentUser(user);
    onUserChange(user);
    setUserDropdownOpen(false);
  };

  const getRoleBadgeColor = (role: Role) => {
    switch (role) {
      case 'ARCHITECTE':
        return 'bg-amber-500/20 text-amber-300 border-amber-400/50 shadow-sm shadow-amber-500/30';
      case 'SUPERADMIN':
        return 'bg-purple-900/60 text-purple-200 border-purple-500/40';
      case 'ADMIN':
        return 'bg-blue-900/60 text-blue-200 border-blue-500/40';
      case 'MAGASINIER':
        return 'bg-amber-900/60 text-amber-200 border-amber-500/40';
      case 'CAISSIER':
        return 'bg-emerald-900/60 text-emerald-200 border-emerald-500/40';
      case 'COMPTABLE':
        return 'bg-cyan-900/60 text-cyan-200 border-cyan-500/40';
      case 'INVITE':
        return 'bg-slate-800 text-slate-300 border-slate-600';
    }
  };

  return (
    <header className="no-print bg-slate-900 border-b border-slate-800 text-slate-100 select-none shadow-md">
      {/* Top simulated Windows title bar */}
      <div className="flex items-center justify-between px-3 py-1 bg-slate-950 text-xs text-slate-400 border-b border-slate-900">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 font-semibold text-slate-300">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-500 inline-block shadow-sm shadow-blue-500/50"></span>
            <span>MAISON MP MOTORS</span>
            <span className="text-slate-600">|</span>
            <span className="text-slate-400 font-normal">Gestion de Quincaillerie Automobile (Comptoir)</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Database Engine indicator & quick config */}
          <button
            onClick={() => onOpenDbConfig?.()}
            className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-blue-500/60 text-slate-300 hover:text-white font-medium cursor-pointer transition-colors"
            title="Configurer le moteur de base de données & lancer test CRUD"
          >
            <Database className="w-3.5 h-3.5 text-blue-400" />
            <span className="hidden sm:inline">Base :</span>
            <span className="text-emerald-400 font-bold text-[10px]">
              {dbConfig.engine === 'SQLITE_EMBEDDED' ? 'SQLite' : dbConfig.engine === 'POSTGRESQL' ? 'PostgreSQL' : dbConfig.engine === 'MYSQL_MARIADB' ? 'MySQL' : 'Local'}
            </span>
            <span className="text-[9px] text-slate-400 font-mono">({dbConfig.lastLatencyMs || 2}ms)</span>
          </button>

          {/* Offline indicator */}
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-emerald-950/80 border border-emerald-800/60 text-emerald-400 font-medium">
            <WifiOff className="w-3.5 h-3.5" />
            <span>100% Hors Ligne</span>
          </div>

          {/* Clock */}
          <div className="flex items-center gap-1 text-slate-300 font-mono">
            <Clock className="w-3 h-3 text-slate-500" />
            <span>{time}</span>
          </div>

          {/* Window controls decoration */}
          <div className="flex items-center gap-1.5 ml-2 pl-2 border-l border-slate-800">
            <span className="w-3 h-3 rounded-full bg-slate-700/60 inline-block"></span>
            <span className="w-3 h-3 rounded-full bg-slate-700/60 inline-block"></span>
            <span className="w-3 h-3 rounded-full bg-blue-600/80 inline-block"></span>
          </div>
        </div>
      </div>

      {/* Primary operational bar */}
      <div className="flex items-center justify-between px-4 py-2.5">
        {/* Company Identity */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-600 to-indigo-800 flex items-center justify-center shadow-lg shadow-blue-900/40 border border-blue-500/30 overflow-hidden">
            {params.logoDataUrl ? (
              <img src={params.logoDataUrl} alt="Logo" className="w-full h-full object-cover" />
            ) : (
              <Wrench className="w-5 h-5 text-white" />
            )}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-bold text-white tracking-wide uppercase">
                {params.entrepriseNom || 'MAISON MP MOTORS'}
              </h1>
              <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-500/30">
                Kinshasa
              </span>
            </div>
            <p className="text-xs text-slate-400 truncate max-w-sm">
              {params.adresse}
            </p>
          </div>
        </div>

        {/* Currency rate badge & controls */}
        <div className="flex items-center gap-3">
          {/* Taux USD / CDF */}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800/80 border border-slate-700 shadow-inner">
            <div className="p-1 rounded bg-blue-500/20 text-blue-400">
              <DollarSign className="w-4 h-4" />
            </div>
            <div className="text-left">
              <div className="text-[10px] text-slate-400 font-semibold uppercase leading-tight">
                Taux du jour
              </div>
              <div className="text-xs font-bold text-white font-mono">
                1 USD = <span className="text-emerald-400">{params.tauxUSD_CDF.toLocaleString('fr-FR')} CDF</span>
              </div>
            </div>
          </div>

          {/* Keyboard shortcuts trigger */}
          <button
            onClick={onOpenShortcuts}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-medium text-slate-300 transition-colors"
            title="Afficher les raccourcis clavier [F1]"
          >
            <Keyboard className="w-4 h-4 text-blue-400" />
            <span className="hidden sm:inline">Raccourcis</span>
            <kbd className="px-1.5 py-0.5 text-[10px] bg-slate-900 rounded border border-slate-600 font-mono text-slate-300">
              F1
            </kbd>
          </button>

          {/* Theme & Display Mode Customizer */}
          {onOpenThemeConfig && (
            <button
              onClick={onOpenThemeConfig}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-medium text-slate-300 transition-all cursor-pointer shadow-xs"
              title="Personnaliser le mode d'affichage (sombre/clair) et les couleurs"
            >
              <Palette className="w-4 h-4 text-purple-400" />
              <span className="hidden md:inline">Thème & Couleurs</span>
            </button>
          )}

          {/* Direct Download Windows Package Button */}
          <a
            href="/downloads/Maison_MP_Motors_Windows_x64.zip"
            download="Maison_MP_Motors_Windows_x64.zip"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold transition-all shadow-md shadow-emerald-600/30 cursor-pointer border border-emerald-400/40"
            title="Télécharger l'archive complète avec lanceur Windows 1-clic (.zip)"
          >
            <Download className="w-4 h-4" />
            <span className="hidden sm:inline">Pack Windows (.ZIP)</span>
          </a>

          {/* Active User session & Switcher */}
          <div className="relative">
            {(() => {
              const currentLicense = getUserLicenseStatus(currentUser, params.licenceGlobaleAVie);
              return (
                <button
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className={`flex items-center gap-2.5 px-3 py-1.5 rounded-lg border text-left transition-all cursor-pointer ${
                    currentUser.role === 'ARCHITECTE'
                      ? 'bg-amber-950/30 hover:bg-amber-950/50 border-amber-500/40 shadow-sm shadow-amber-500/20'
                      : currentLicense.estExpire
                      ? 'bg-red-950/40 hover:bg-red-950/60 border-red-500/50 animate-pulse'
                      : 'bg-slate-800 hover:bg-slate-750 border-slate-700'
                  }`}
                >
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold border ${
                    currentUser.role === 'ARCHITECTE'
                      ? 'bg-amber-500 text-slate-950 border-amber-300 font-extrabold'
                      : 'bg-slate-700 text-blue-300 border-slate-600'
                  }`}>
                    {currentUser.role === 'ARCHITECTE' ? <Crown className="w-4 h-4" /> : currentUser.nom.charAt(0)}
                  </div>
                  <div className="text-left">
                    <div className="text-xs font-bold text-slate-100 flex items-center gap-1.5">
                      <span>{currentUser.nom}</span>
                      <span className={`text-[10px] px-1.5 py-0.2 rounded border font-semibold ${getRoleBadgeColor(currentUser.role)}`}>
                        {currentUser.role}
                      </span>
                    </div>
                    <div className="text-[10px] flex items-center gap-1.5 mt-0.5">
                      <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold border ${currentLicense.badgeColor}`}>
                        {currentLicense.label}
                      </span>
                      <span className="text-slate-400">▼</span>
                    </div>
                  </div>
                </button>
              );
            })()}

            {/* Dropdown to test/switch roles */}
            {userDropdownOpen && (
              <div className="absolute right-0 mt-2 w-72 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl py-2 z-50">
                <div className="px-3 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-800 flex items-center justify-between">
                  <span>Changer de session de travail</span>
                  <span className="text-[10px] text-blue-400 lowercase">({allUsers.length} comptes)</span>
                </div>
                <div className="max-h-80 overflow-y-auto">
                  {allUsers.map((u) => {
                    const uLic = getUserLicenseStatus(u, params.licenceGlobaleAVie);
                    return (
                      <button
                        key={u.id}
                        onClick={() => handleSwitchUser(u)}
                        className={`w-full flex items-center justify-between px-3 py-2.5 text-left hover:bg-slate-800 transition-colors border-b border-slate-800/40 ${
                          currentUser.id === u.id ? 'bg-blue-600/10 text-blue-300' : 'text-slate-200'
                        }`}
                      >
                        <div>
                          <div className="text-xs font-semibold flex items-center gap-1.5">
                            {u.role === 'ARCHITECTE' && <Crown className="w-3.5 h-3.5 text-amber-400" />}
                            <span>{u.nom}</span>
                          </div>
                          <div className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5">
                            <span>@{u.identifiant}</span>
                            <span>•</span>
                            <span className="text-slate-300">{uLic.dateExpirationFormatee}</span>
                          </div>
                        </div>

                        <div className="text-right flex flex-col items-end gap-1">
                          <span className={`text-[10px] px-1.5 py-0.2 rounded border font-semibold ${getRoleBadgeColor(u.role)}`}>
                            {u.role}
                          </span>
                          <span className={`text-[9px] px-1 py-0.2 rounded border font-mono ${uLic.badgeColor}`}>
                            {uLic.estIllimite ? 'À VIE ♾️' : uLic.estExpire ? 'EXPIRÉ' : `${uLic.joursRestants}j`}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {onLogout && (
                  <div className="p-2 border-t border-slate-800 bg-slate-950/90">
                    <button
                      type="button"
                      onClick={() => {
                        setUserDropdownOpen(false);
                        onLogout();
                      }}
                      className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-lg bg-red-600/20 hover:bg-red-600/30 text-red-300 border border-red-500/30 text-xs font-bold transition-all cursor-pointer"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Verrouiller / Se Déconnecter</span>
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Quick Direct Logout Button */}
          {onLogout && (
            <button
              type="button"
              onClick={onLogout}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-red-950/60 border border-slate-700 hover:border-red-500/40 text-slate-400 hover:text-red-300 transition-colors cursor-pointer"
              title="Se déconnecter (Verrouiller la session)"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden xl:inline text-xs font-semibold">Déconnexion</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
